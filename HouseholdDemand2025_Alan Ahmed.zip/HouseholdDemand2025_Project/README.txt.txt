═══════════════════════════════════════════════════════════════
  FINNISH HOUSEHOLD ELECTRICITY CONSUMPTION ANALYSIS 2025
═══════════════════════════════════════════════════════════════

Student: Alan Ahmed
Course: Data Intelligence Launchpad (Courses 5-6)
Institution: Metropolia University of Applied Sciences
Submission Date: November 2025

═══════════════════════════════════════════════════════════════
  PROJECT SUMMARY
═══════════════════════════════════════════════════════════════

This project analyzes 38.02 billion kWh of Finnish electricity 
consumption data using Microsoft Fabric and Power BI Direct Lake.

Key Achievements:
✓ Implemented medallion architecture (Bronze-Silver-Gold)
✓ Built interactive Power BI dashboard with drill-down
✓ Analyzed 10 months of hourly data across 14 user groups
✓ Created comprehensive documentation
✓ Published complete code on GitHub
✓ Deployed to Power BI Service

═══════════════════════════════════════════════════════════════
  TECHNOLOGIES USED
═══════════════════════════════════════════════════════════════

Cloud Platform:    Microsoft Fabric
Data Storage:      Delta Lake (Parquet format)
Transformation:    Spark SQL
Data Modeling:     Star Schema (1 fact, 3 dimensions)
Visualization:     Power BI Service
Connection:        Direct Lake (real-time)
Version Control:   GitHub (public repository)
Documentation:     Microsoft Word → PDF

═══════════════════════════════════════════════════════════════
  KEY METRICS
═══════════════════════════════════════════════════════════════

Data Volume:       38.02 billion kWh analyzed
Time Period:       January - October 2025 (10 months)
Granularity:       Hourly data
User Groups:       14 categories (BE01-BE14)
Fact Records:      ~96,000 rows
Data Source:       Fingrid Open Data API (Dataset 360)

Top Consumers:
  1. Services            - 9.2bn kWh (24%)
  2. Small Buildings     - 7.9bn kWh (21%)
  3. Industry            - 7.3bn kWh (19%)

═══════════════════════════════════════════════════════════════
  CONTACT INFORMATION
═══════════════════════════════════════════════════════════════

Student Email:     alanahm@metropolia.fi
GitHub:            https://github.com/AlanBlbas
LinkedIn:          https://www.linkedin.com/in/alan-blbas-524300121/

Project Repository:
https://github.com/AlanBlbas/Finnish-Household-Electricity-Insights

Power BI Dashboard:
Published in workspace: HouseholdDemand2025

═══════════════════════════════════════════════════════════════
  ACKNOWLEDGMENTS
═══════════════════════════════════════════════════════════════

• Fingrid Datahub for open data access
• Metropolia UAS instructors for guidance
• Microsoft for Fabric platform and documentation
• Open source community for tools and inspiration

═══════════════════════════════════════════════════════════════
  LICENSE & USAGE
═══════════════════════════════════════════════════════════════

Code:              MIT License (see GitHub)
Data Source:       Fingrid Open Data (public)
Documentation:     Educational use permitted
Report:            For academic evaluation

═══════════════════════════════════════════════════════════════
End of README - Thank you for reviewing my project!
═══════════════════════════════════════════════════════════════
